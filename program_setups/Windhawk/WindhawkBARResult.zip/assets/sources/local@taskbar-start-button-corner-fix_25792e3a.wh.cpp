// ==WindhawkMod==
// @id              taskbar-start-button-corner-fix
// @name            Start Menu Corner Click Fix
// @description     Fixes the issue where clicking in the corner of the taskbar doesn't open the Start menu on multi monitor setups.
// @version         2.0
// @author          Alchemy
// @github          https://github.com/alchemyyy
// @license         MIT
// @include         explorer.exe
// @architecture    x86-64
// @compilerOptions -lole32 -loleaut32 -luser32
// ==/WindhawkMod==

// ==WindhawkModReadme==
/*
# Start Menu Corner Click Fix

Fixes the issue where clicking the bottom-left corner of a left-aligned taskbar
doesn't reliably open the Start menu when another monitor is adjacent to that edge.

## How it works

The Windows 11 taskbar receives mouse input as `WM_POINTER` messages through an
InputSite window. The mod intercepts the pointer pair in the configured corner
region, prevents the original sticky-corner path from handling it, and invokes
the Start button belonging to the clicked taskbar after mouse-up.

UI Automation runs on a dedicated worker thread, never on the taskbar input
thread. If the Start button can't be invoked, the mod falls back to pressing the
Windows key.

## Requirements

- Windows 11 64-bit (tested on 25H2)
- A left-aligned taskbar
- Windhawk v1.4 or later
*/
// ==/WindhawkModReadme==

// ==WindhawkModSettings==
/*
- edgeThickness: 5
  $name: Edge thickness
  $description: Thickness of the L-shaped edge region in pixels
- edgeLength: 15
  $name: Edge length
  $description: Length of each arm of the L-shaped corner region in pixels
*/
// ==/WindhawkModSettings==

#include <windows.h>
#include <windowsx.h>
#include <objbase.h>
#include <uiautomation.h>

#include <atomic>

#include <windhawk_utils.h>

namespace {

constexpr wchar_t kInputSiteClassName[] =
    L"Windows.UI.Input.InputSite.WindowClass";
constexpr wchar_t kContentBridgeClassName[] =
    L"Windows.UI.Composition.DesktopWindowContentBridge";
constexpr wchar_t kPrimaryTaskbarClassName[] = L"Shell_TrayWnd";
constexpr wchar_t kSecondaryTaskbarClassName[] = L"Shell_SecondaryTrayWnd";
constexpr wchar_t kStartButtonAutomationID[] = L"StartButton";
constexpr int kDefaultEdgeThickness = 5;
constexpr int kDefaultEdgeLength = 15;
constexpr UINT kStartMenuActivationMessage = WM_APP + 1;

struct Settings {
    std::atomic<int> edgeThickness{kDefaultEdgeThickness};
    std::atomic<int> edgeLength{kDefaultEdgeLength};
};

struct CornerPointerState {
    HWND inputSiteWindow = nullptr;
    HWND taskbarWindow = nullptr;
    UINT32 pointerID = 0;
    bool suppressing = false;
    bool activationCanceled = false;
};

enum class HookLifecycle {
    Initializing,
    Running,
    Unloading,
};

Settings g_settings;
thread_local CornerPointerState g_cornerPointerState;

SRWLOCK g_hookOperationLock = SRWLOCK_INIT;
HookLifecycle g_hookLifecycle = HookLifecycle::Initializing;
void* g_inputSiteWindowProcTarget = nullptr;
WNDPROC g_inputSiteWindowProcOriginal = nullptr;
bool g_inputSiteWindowProcHookPending = false;

SRWLOCK g_startMenuActivationLock = SRWLOCK_INIT;
HANDLE g_startMenuActivationThread = nullptr;
DWORD g_startMenuActivationThreadID = 0;
bool g_acceptStartMenuActivations = false;

using CreateWindowInBand_t = HWND(WINAPI*)(DWORD extendedStyle,
                                           LPCWSTR className,
                                           LPCWSTR windowName,
                                           DWORD style,
                                           int x,
                                           int y,
                                           int width,
                                           int height,
                                           HWND parentWindow,
                                           HMENU menu,
                                           HINSTANCE instance,
                                           void* parameter,
                                           DWORD band);

CreateWindowInBand_t g_createWindowInBandOriginal = nullptr;

int GetPositiveSetting(const std::atomic<int>& setting, int defaultValue) {
    int value = setting.load(std::memory_order_relaxed);
    return value > 0 ? value : defaultValue;
}

bool IsClassName(HWND window, const wchar_t* expectedClassName) {
    wchar_t className[128];
    int length = GetClassNameW(window, className, ARRAYSIZE(className));
    return length > 0 && wcscmp(className, expectedClassName) == 0;
}

bool IsTaskbarWindow(HWND window) {
    if (!window) {
        return false;
    }

    DWORD processID = 0;
    if (!GetWindowThreadProcessId(window, &processID) ||
        processID != GetCurrentProcessId()) {
        return false;
    }

    return IsClassName(window, kPrimaryTaskbarClassName) ||
           IsClassName(window, kSecondaryTaskbarClassName);
}

bool IsTaskbarInputSite(HWND window) {
    if (!window || !IsClassName(window, kInputSiteClassName)) {
        return false;
    }

    HWND parentWindow = GetParent(window);
    if (!parentWindow ||
        !IsClassName(parentWindow, kContentBridgeClassName)) {
        return false;
    }

    return IsTaskbarWindow(GetAncestor(window, GA_ROOT));
}

bool IsMousePointer(UINT32 pointerID) {
    if (pointerID == 0) {
        return true;
    }

    POINTER_INPUT_TYPE pointerType = PT_POINTER;
    return GetPointerType(pointerID, &pointerType) && pointerType == PT_MOUSE;
}

bool IsInCornerRegion(HWND taskbarWindow, POINT point) {
    RECT taskbarRectangle;
    if (!GetWindowRect(taskbarWindow, &taskbarRectangle) ||
        !PtInRect(&taskbarRectangle, point)) {
        return false;
    }

    HMONITOR taskbarMonitor =
        MonitorFromWindow(taskbarWindow, MONITOR_DEFAULTTONULL);
    HMONITOR pointMonitor = MonitorFromPoint(point, MONITOR_DEFAULTTONULL);
    if (!taskbarMonitor || taskbarMonitor != pointMonitor) {
        return false;
    }

    MONITORINFO monitorInfo = {};
    monitorInfo.cbSize = sizeof(monitorInfo);
    if (!GetMonitorInfoW(taskbarMonitor, &monitorInfo)) {
        return false;
    }

    POINT adjacentPoint = {
        monitorInfo.rcMonitor.left - 1,
        point.y,
    };
    HMONITOR adjacentMonitor =
        MonitorFromPoint(adjacentPoint, MONITOR_DEFAULTTONULL);
    if (!adjacentMonitor || adjacentMonitor == taskbarMonitor) {
        return false;
    }

    MONITORINFO adjacentMonitorInfo = {};
    adjacentMonitorInfo.cbSize = sizeof(adjacentMonitorInfo);
    if (!GetMonitorInfoW(adjacentMonitor, &adjacentMonitorInfo) ||
        adjacentMonitorInfo.rcMonitor.right != monitorInfo.rcMonitor.left) {
        return false;
    }

    LONG distanceFromLeft = point.x - monitorInfo.rcMonitor.left;
    LONG distanceFromBottom = monitorInfo.rcMonitor.bottom - 1 - point.y;
    int edgeLength =
        GetPositiveSetting(g_settings.edgeLength, kDefaultEdgeLength);
    if (distanceFromLeft < 0 || distanceFromLeft >= edgeLength ||
        distanceFromBottom < 0 || distanceFromBottom >= edgeLength) {
        return false;
    }

    int edgeThickness =
        GetPositiveSetting(g_settings.edgeThickness, kDefaultEdgeThickness);
    return distanceFromLeft < edgeThickness ||
           distanceFromBottom < edgeThickness;
}

POINT GetPointerPoint(LPARAM parameter) {
    POINT point = {};
    point.x = GET_X_LPARAM(parameter);
    point.y = GET_Y_LPARAM(parameter);
    return point;
}

void ClearCornerPointerState() {
    g_cornerPointerState = {};
}

bool IsActiveCornerPointer(HWND inputSiteWindow, UINT32 pointerID) {
    return g_cornerPointerState.suppressing &&
           g_cornerPointerState.inputSiteWindow == inputSiteWindow &&
           g_cornerPointerState.pointerID == pointerID;
}

// Creates the reusable condition used to find each taskbar's Start button
IUIAutomationCondition* CreateStartButtonCondition(
    IUIAutomation* automation) {
    BSTR automationID = SysAllocString(kStartButtonAutomationID);
    if (!automationID) {
        Wh_Log(L"Failed to allocate the Start button automation ID");
        return nullptr;
    }

    VARIANT automationIDValue = {};
    automationIDValue.vt = VT_BSTR;
    automationIDValue.bstrVal = automationID;

    IUIAutomationCondition* condition = nullptr;
    HRESULT operationResult = automation->CreatePropertyCondition(
        UIA_AutomationIdPropertyId, automationIDValue, &condition);
    SysFreeString(automationID);

    if (FAILED(operationResult) || !condition) {
        Wh_Log(L"Failed to create the Start button condition (error: "
               L"0x%08X)",
               static_cast<unsigned int>(operationResult));
        return nullptr;
    }

    return condition;
}

// Activates the Start button belonging to the specified taskbar
bool ActivateTaskbarStartButton(IUIAutomation* automation,
                                IUIAutomationCondition* condition,
                                HWND taskbarWindow) {
    if (!automation || !condition || !IsTaskbarWindow(taskbarWindow)) {
        return false;
    }

    IUIAutomationElement* taskbarElement = nullptr;
    HRESULT operationResult =
        automation->ElementFromHandle(taskbarWindow, &taskbarElement);
    if (FAILED(operationResult) || !taskbarElement) {
        Wh_Log(L"Failed to get the UI Automation element for taskbar %p "
               L"(error: 0x%08X)",
               taskbarWindow, static_cast<unsigned int>(operationResult));
        return false;
    }

    IUIAutomationElement* startButton = nullptr;
    operationResult = taskbarElement->FindFirst(
        TreeScope_Descendants, condition, &startButton);
    taskbarElement->Release();
    if (FAILED(operationResult) || !startButton) {
        Wh_Log(L"Failed to find the Start button for taskbar %p (error: "
               L"0x%08X)",
               taskbarWindow, static_cast<unsigned int>(operationResult));
        return false;
    }

    IUIAutomationTogglePattern* togglePattern = nullptr;
    operationResult = startButton->GetCurrentPatternAs(
        UIA_TogglePatternId, __uuidof(IUIAutomationTogglePattern),
        reinterpret_cast<void**>(&togglePattern));
    startButton->Release();
    if (FAILED(operationResult) || !togglePattern) {
        Wh_Log(L"Failed to get the Start button toggle pattern for taskbar "
               L"%p (error: 0x%08X)",
               taskbarWindow, static_cast<unsigned int>(operationResult));
        return false;
    }

    operationResult = togglePattern->Toggle();
    togglePattern->Release();
    if (FAILED(operationResult)) {
        Wh_Log(L"Failed to toggle the Start button for taskbar %p (error: "
               L"0x%08X)",
               taskbarWindow, static_cast<unsigned int>(operationResult));
        return false;
    }

    Wh_Log(L"Activated the Start button for taskbar %p", taskbarWindow);
    return true;
}

bool SendWindowsKeyPress() {
    INPUT inputs[2] = {};
    inputs[0].type = INPUT_KEYBOARD;
    inputs[0].ki.wVk = VK_LWIN;
    inputs[1].type = INPUT_KEYBOARD;
    inputs[1].ki.wVk = VK_LWIN;
    inputs[1].ki.dwFlags = KEYEVENTF_KEYUP;

    UINT inputCount = static_cast<UINT>(ARRAYSIZE(inputs));
    UINT sentInputCount = SendInput(inputCount, inputs, sizeof(INPUT));
    if (sentInputCount != inputCount) {
        Wh_Log(L"Failed to send the Windows key press (sent: %u, error: "
               L"%lu)",
               sentInputCount, GetLastError());
        return false;
    }

    Wh_Log(L"Sent the Windows key press");
    return true;
}

// Processes UI Automation away from the taskbar input thread
DWORD WINAPI StartMenuActivationThreadProc(void* parameter) {
    HANDLE initializationEvent = static_cast<HANDLE>(parameter);
    MSG initializationMessage = {};
    PeekMessageW(
        &initializationMessage, nullptr, WM_USER, WM_USER, PM_NOREMOVE);
    if (!SetEvent(initializationEvent)) {
        Wh_Log(L"Failed to signal Start menu activation thread "
               L"initialization (error: %lu)",
               GetLastError());
    }

    HRESULT COMInitializationResult =
        CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    bool COMInitialized = SUCCEEDED(COMInitializationResult);
    if (!COMInitialized) {
        Wh_Log(L"Failed to initialize COM on the Start menu activation "
               L"thread (error: 0x%08X)",
               static_cast<unsigned int>(COMInitializationResult));
    }

    IUIAutomation* automation = nullptr;
    IUIAutomationCondition* startButtonCondition = nullptr;
    if (COMInitialized) {
        HRESULT operationResult = CoCreateInstance(
            __uuidof(CUIAutomation), nullptr, CLSCTX_INPROC_SERVER,
            __uuidof(IUIAutomation),
            reinterpret_cast<void**>(&automation));
        if (FAILED(operationResult) || !automation) {
            Wh_Log(L"Failed to create the UI Automation instance (error: "
                   L"0x%08X)",
                   static_cast<unsigned int>(operationResult));
            automation = nullptr;
        } else {
            startButtonCondition =
                CreateStartButtonCondition(automation);
        }
    }

    MSG message = {};
    while (true) {
        BOOL messageResult = GetMessageW(&message, nullptr, 0, 0);
        if (messageResult == -1) {
            Wh_Log(L"Start menu activation thread message retrieval failed "
                   L"(error: %lu)",
                   GetLastError());
            break;
        }
        if (messageResult == 0) {
            break;
        }
        if (message.message != kStartMenuActivationMessage) {
            continue;
        }

        HWND taskbarWindow = reinterpret_cast<HWND>(message.wParam);
        if (!ActivateTaskbarStartButton(
                automation, startButtonCondition, taskbarWindow)) {
            Wh_Log(L"Falling back to the Windows key for taskbar %p",
                   taskbarWindow);
            SendWindowsKeyPress();
        }
    }

    if (startButtonCondition) {
        startButtonCondition->Release();
    }
    if (automation) {
        automation->Release();
    }
    if (COMInitialized) {
        CoUninitialize();
    }

    return 0;
}

bool InitializeStartMenuActivationWorker() {
    HANDLE initializationEvent =
        CreateEventW(nullptr, TRUE, FALSE, nullptr);
    if (!initializationEvent) {
        Wh_Log(L"Failed to create the Start menu worker initialization event "
               L"(error: %lu)",
               GetLastError());
        return false;
    }

    DWORD activationThreadID = 0;
    HANDLE activationThread = CreateThread(
        nullptr, 0, StartMenuActivationThreadProc, initializationEvent, 0,
        &activationThreadID);
    if (!activationThread) {
        DWORD error = GetLastError();
        CloseHandle(initializationEvent);
        Wh_Log(L"Failed to create the Start menu activation thread "
               L"(error: %lu)",
               error);
        return false;
    }

    DWORD initializationWaitResult =
        WaitForSingleObject(initializationEvent, INFINITE);
    CloseHandle(initializationEvent);
    if (initializationWaitResult != WAIT_OBJECT_0) {
        DWORD error = GetLastError();
        PostThreadMessageW(activationThreadID, WM_QUIT, 0, 0);
        WaitForSingleObject(activationThread, INFINITE);
        CloseHandle(activationThread);
        Wh_Log(L"Failed to initialize the Start menu activation thread "
               L"(result: 0x%08X, error: %lu)",
               initializationWaitResult, error);
        return false;
    }

    AcquireSRWLockExclusive(&g_startMenuActivationLock);
    g_startMenuActivationThread = activationThread;
    g_startMenuActivationThreadID = activationThreadID;
    g_acceptStartMenuActivations = true;
    ReleaseSRWLockExclusive(&g_startMenuActivationLock);
    Wh_Log(L"Started the Start menu activation thread %lu",
           activationThreadID);
    return true;
}

void ShutdownStartMenuActivationWorker() {
    HANDLE activationThread = nullptr;
    DWORD activationThreadID = 0;
    DWORD error = ERROR_SUCCESS;

    AcquireSRWLockExclusive(&g_startMenuActivationLock);
    g_acceptStartMenuActivations = false;
    activationThread = g_startMenuActivationThread;
    activationThreadID = g_startMenuActivationThreadID;
    if (activationThreadID &&
        !PostThreadMessageW(activationThreadID, WM_QUIT, 0, 0)) {
        error = GetLastError();
    }
    ReleaseSRWLockExclusive(&g_startMenuActivationLock);

    if (error != ERROR_SUCCESS) {
        Wh_Log(L"Failed to signal the Start menu activation thread to stop "
               L"(error: %lu)",
               error);
    }

    if (activationThread) {
        DWORD waitResult =
            WaitForSingleObject(activationThread, INFINITE);
        if (waitResult != WAIT_OBJECT_0) {
            Wh_Log(L"Failed to wait for the Start menu activation thread "
                   L"(result: 0x%08X, error: %lu)",
                   waitResult, GetLastError());
        }
    }

    AcquireSRWLockExclusive(&g_startMenuActivationLock);
    if (g_startMenuActivationThread) {
        CloseHandle(g_startMenuActivationThread);
        g_startMenuActivationThread = nullptr;
    }
    g_startMenuActivationThreadID = 0;
    ReleaseSRWLockExclusive(&g_startMenuActivationLock);
}

bool QueueStartMenuActivation(HWND taskbarWindow) {
    bool activationQueued = false;
    DWORD error = ERROR_SUCCESS;

    AcquireSRWLockExclusive(&g_startMenuActivationLock);
    if (g_acceptStartMenuActivations &&
        g_startMenuActivationThreadID != 0) {
        if (PostThreadMessageW(
                g_startMenuActivationThreadID,
                kStartMenuActivationMessage,
                reinterpret_cast<WPARAM>(taskbarWindow), 0)) {
            activationQueued = true;
        } else {
            error = GetLastError();
        }
    }
    ReleaseSRWLockExclusive(&g_startMenuActivationLock);

    if (!activationQueued) {
        if (error != ERROR_SUCCESS) {
            Wh_Log(L"Failed to queue Start menu activation for taskbar %p "
                   L"(error: %lu)",
                   taskbarWindow, error);
        }
        return false;
    }

    Wh_Log(L"Queued Start menu activation for taskbar %p", taskbarWindow);
    return true;
}

LRESULT HandleInputSiteWindowMessage(WNDPROC originalWindowProc,
                                     HWND window,
                                     UINT message,
                                     WPARAM wParam,
                                     LPARAM lParam) {
    if (!originalWindowProc) {
        return DefWindowProcW(window, message, wParam, lParam);
    }

    // The hooked procedure is shared by every InputSite window in Explorer
    switch (message) {
        case WM_POINTERDOWN:
        case WM_POINTERUPDATE:
        case WM_POINTERUP:
        case WM_POINTERCAPTURECHANGED:
        case WM_POINTERLEAVE:
        case WM_CANCELMODE:
        case WM_NCDESTROY:
            break;

        default:
            return originalWindowProc(window, message, wParam, lParam);
    }

    switch (message) {
        case WM_POINTERDOWN: {
            UINT32 pointerID = GET_POINTERID_WPARAM(wParam);
            if (!IS_POINTER_FIRSTBUTTON_WPARAM(wParam) ||
                !IsMousePointer(pointerID)) {
                break;
            }

            HWND taskbarWindow = GetAncestor(window, GA_ROOT);
            if (!IsTaskbarWindow(taskbarWindow)) {
                break;
            }

            ClearCornerPointerState();

            POINT point = GetPointerPoint(lParam);
            if (!IsInCornerRegion(taskbarWindow, point)) {
                break;
            }

            g_cornerPointerState.inputSiteWindow = window;
            g_cornerPointerState.taskbarWindow = taskbarWindow;
            g_cornerPointerState.pointerID = pointerID;
            g_cornerPointerState.suppressing = true;

            Wh_Log(L"Intercepted corner pointer down at (%ld, %ld), "
                   L"pointer %u, InputSite %p, taskbar %p",
                   point.x, point.y, pointerID, window, taskbarWindow);

            return 0;
        }

        case WM_POINTERUPDATE: {
            UINT32 pointerID = GET_POINTERID_WPARAM(wParam);
            if (IsActiveCornerPointer(window, pointerID)) {
                if (IS_POINTER_CANCELED_WPARAM(wParam)) {
                    g_cornerPointerState.activationCanceled = true;
                }
                return 0;
            }
            break;
        }

        case WM_POINTERUP: {
            UINT32 pointerID = GET_POINTERID_WPARAM(wParam);
            if (!IsActiveCornerPointer(window, pointerID)) {
                break;
            }

            HWND clickedTaskbarWindow =
                g_cornerPointerState.taskbarWindow;
            POINT point = GetPointerPoint(lParam);
            bool pointerCanceled =
                g_cornerPointerState.activationCanceled ||
                IS_POINTER_CANCELED_WPARAM(wParam);
            bool releasedInCorner = !pointerCanceled &&
                IsInCornerRegion(clickedTaskbarWindow, point);
            ClearCornerPointerState();

            if (releasedInCorner) {
                Wh_Log(L"Intercepted corner pointer up at (%ld, %ld), "
                       L"pointer %u",
                       point.x, point.y, pointerID);
                QueueStartMenuActivation(clickedTaskbarWindow);
            } else {
                if (pointerCanceled) {
                    Wh_Log(L"Canceled corner click after pointer cancellation");
                } else {
                    Wh_Log(L"Canceled corner click after pointer left the "
                           L"region");
                }
            }

            return 0;
        }

        case WM_POINTERCAPTURECHANGED: {
            UINT32 pointerID = GET_POINTERID_WPARAM(wParam);
            if (IsActiveCornerPointer(window, pointerID)) {
                ClearCornerPointerState();
                return 0;
            }
            break;
        }

        case WM_POINTERLEAVE: {
            UINT32 pointerID = GET_POINTERID_WPARAM(wParam);
            if (IsActiveCornerPointer(window, pointerID)) {
                ClearCornerPointerState();
                return 0;
            }
            break;
        }

        case WM_CANCELMODE:
            if (g_cornerPointerState.inputSiteWindow == window) {
                g_cornerPointerState.activationCanceled = true;
            }
            break;

        case WM_NCDESTROY:
            if (g_cornerPointerState.inputSiteWindow == window) {
                ClearCornerPointerState();
            }
            break;
    }

    return originalWindowProc(window, message, wParam, lParam);
}

// InputSite rejects subclassed window procedures, so hook its shared procedure
LRESULT CALLBACK InputSiteWindowProc_Hook(HWND window,
                                          UINT message,
                                          WPARAM wParam,
                                          LPARAM lParam) {
    return HandleInputSiteWindowMessage(
        g_inputSiteWindowProcOriginal, window, message, wParam, lParam);
}

bool HookInputSiteWindowProc(HWND inputSiteWindow) {
    if (!IsTaskbarInputSite(inputSiteWindow)) {
        return false;
    }

    void* windowProc = reinterpret_cast<void*>(
        GetWindowLongPtrW(inputSiteWindow, GWLP_WNDPROC));
    if (!windowProc) {
        Wh_Log(L"Failed to get InputSite window procedure for %p "
               L"(error: %lu)",
               inputSiteWindow, GetLastError());
        return false;
    }

    AcquireSRWLockExclusive(&g_hookOperationLock);
    if (g_hookLifecycle == HookLifecycle::Unloading) {
        ReleaseSRWLockExclusive(&g_hookOperationLock);
        return false;
    }

    if (g_inputSiteWindowProcTarget &&
        g_inputSiteWindowProcTarget != windowProc) {
        Wh_Log(L"Taskbar InputSite window %p has an unexpected window "
               L"procedure %p; the shared procedure %p is already hooked",
               inputSiteWindow, windowProc,
               g_inputSiteWindowProcTarget);
        ReleaseSRWLockExclusive(&g_hookOperationLock);
        return false;
    }

    bool hookConfigured = g_inputSiteWindowProcTarget != nullptr;
    if (!hookConfigured) {
        if (!Wh_SetFunctionHook(
                windowProc,
                reinterpret_cast<void*>(InputSiteWindowProc_Hook),
                reinterpret_cast<void**>(
                    &g_inputSiteWindowProcOriginal))) {
            Wh_Log(L"Failed to configure InputSite window procedure hook "
                   L"for %p",
                   inputSiteWindow);
            ReleaseSRWLockExclusive(&g_hookOperationLock);
            return false;
        }

        g_inputSiteWindowProcTarget = windowProc;
        g_inputSiteWindowProcHookPending = true;
        hookConfigured = true;
        Wh_Log(L"Configured the shared taskbar InputSite window procedure "
               L"hook: window %p, procedure %p",
               inputSiteWindow, windowProc);
    }

    if (g_inputSiteWindowProcHookPending &&
        g_hookLifecycle == HookLifecycle::Running) {
        if (Wh_ApplyHookOperations()) {
            g_inputSiteWindowProcHookPending = false;
        } else {
            hookConfigured = false;
            Wh_Log(L"Failed to apply the pending InputSite window procedure "
                   L"hook; the next taskbar scan will retry");
        }
    }
    ReleaseSRWLockExclusive(&g_hookOperationLock);

    return hookConfigured;
}

BOOL CALLBACK FindInputSiteCallback(HWND window, LPARAM) {
    if (IsTaskbarInputSite(window)) {
        HookInputSiteWindowProc(window);
    }

    return TRUE;
}

BOOL CALLBACK FindTaskbarCallback(HWND window, LPARAM) {
    if (IsTaskbarWindow(window)) {
        EnumChildWindows(window, FindInputSiteCallback, 0);
    }

    return TRUE;
}

bool FindAndHookExistingInputSite() {
    EnumWindows(FindTaskbarCallback, 0);

    AcquireSRWLockShared(&g_hookOperationLock);
    bool hookConfigured = g_inputSiteWindowProcTarget != nullptr;
    ReleaseSRWLockShared(&g_hookOperationLock);
    return hookConfigured;
}

HWND WINAPI CreateWindowInBand_Hook(DWORD extendedStyle,
                                    LPCWSTR className,
                                    LPCWSTR windowName,
                                    DWORD style,
                                    int x,
                                    int y,
                                    int width,
                                    int height,
                                    HWND parentWindow,
                                    HMENU menu,
                                    HINSTANCE instance,
                                    void* parameter,
                                    DWORD band) {
    HWND window = g_createWindowInBandOriginal(
        extendedStyle, className, windowName, style, x, y, width, height,
        parentWindow, menu, instance, parameter, band);

    if (window && className && !IS_INTRESOURCE(className) &&
        wcscmp(className, kInputSiteClassName) == 0) {
        HookInputSiteWindowProc(window);
    }

    return window;
}

bool ConfigureCreateWindowInBandHook() {
    HMODULE user32Module = GetModuleHandleW(L"user32.dll");
    if (!user32Module) {
        Wh_Log(L"Failed to get user32.dll");
        return false;
    }

    void* createWindowInBand =
        reinterpret_cast<void*>(
            GetProcAddress(user32Module, "CreateWindowInBand"));
    if (!createWindowInBand) {
        Wh_Log(L"Failed to find CreateWindowInBand");
        return false;
    }

    if (!Wh_SetFunctionHook(
            createWindowInBand,
            reinterpret_cast<void*>(CreateWindowInBand_Hook),
            reinterpret_cast<void**>(&g_createWindowInBandOriginal))) {
        Wh_Log(L"Failed to configure CreateWindowInBand hook");
        return false;
    }

    return true;
}

void LoadSettings() {
    g_settings.edgeThickness.store(
        Wh_GetIntSetting(L"edgeThickness"), std::memory_order_relaxed);
    g_settings.edgeLength.store(
        Wh_GetIntSetting(L"edgeLength"), std::memory_order_relaxed);
}

}  // namespace

BOOL Wh_ModInit() {
    Wh_Log(L"Initializing");

    LoadSettings();

    if (!InitializeStartMenuActivationWorker()) {
        return FALSE;
    }

    bool creationHookConfigured = ConfigureCreateWindowInBandHook();
    bool inputSiteHookConfigured = FindAndHookExistingInputSite();
    if (!creationHookConfigured && !inputSiteHookConfigured) {
        Wh_Log(L"Failed to configure taskbar input hooks");
        ShutdownStartMenuActivationWorker();
        return FALSE;
    }

    Wh_Log(L"Initialized");
    return TRUE;
}

void Wh_ModAfterInit() {
    AcquireSRWLockExclusive(&g_hookOperationLock);
    if (g_hookLifecycle != HookLifecycle::Unloading) {
        g_hookLifecycle = HookLifecycle::Running;
    }
    ReleaseSRWLockExclusive(&g_hookOperationLock);

    // Retry after initial hook application in case the taskbar was recreated
    // while the mod was initializing
    FindAndHookExistingInputSite();
}

void Wh_ModBeforeUninit() {
    AcquireSRWLockExclusive(&g_hookOperationLock);
    g_hookLifecycle = HookLifecycle::Unloading;
    ReleaseSRWLockExclusive(&g_hookOperationLock);

    ShutdownStartMenuActivationWorker();
}

void Wh_ModUninit() {
    Wh_Log(L"Uninitialized");
}

void Wh_ModSettingsChanged() {
    LoadSettings();
    FindAndHookExistingInputSite();
}
