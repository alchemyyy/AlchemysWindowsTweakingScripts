// ==WindhawkMod==
// @id              instant-taskbar-thumbnail-previews
// @name            Instant Taskbar Thumbnail Previews
// @description     Controls taskbar thumbnail show and close behavior and can make grouped clicks open thumbnails instead of cycling windows.
// @version         1.0.0
// @author          Alchemy
// @github          https://github.com/alchemyyy
// @license         MIT
// @include         explorer.exe
// @architecture    x86-64
// @compilerOptions -luser32
// ==/WindhawkMod==

// ==WindhawkModReadme==
/*
# Instant Taskbar Thumbnails

Adds the ability to configure or remove the delays before Windows 11 shows and closes taskbar thumbnail
previews, as well as configure discrete mouse actions to open and close them.

The current Windows 11 taskbar implements this delay in `Taskbar.View.dll`.
It passes a WinRT `TimeSpan` to `HoverFlyoutModel::TransitionToFlyoutVisiblePendingState`.
Registry values such as `ExtendedUIHoverTime`, `TrackMouseEvent`, and generic Win32 taskbar timers do not control this XAML hover path.

The close delay is applied by `HoverFlyoutModel::TransitionToFlyoutDismissPendingState`, which reads `UISettings.MouseHoverTime`.
The mod overrides that value only while the thumbnail dismissal transition is running,
leaving all other Windows hover behavior unchanged.

Both delay settings replace the corresponding Windows value,
so they can make the transitions either shorter or longer than the stock delays.

The optional outside-click behavior arms the taskbar's native light-dismiss action while a thumbnail flyout is open.
Windows evaluates the taskbar InputSite when routing pointer input,
so interaction outside the taskbar and thumbnail surface is detected without foreground ownership or a global input hook.

The optional grouped-click override makes a normal left click open the thumbnail flyout instead of cycling directly through the group's windows.
Ctrl+click retains the opposite cycling action.

This mod targets the new Windows 11 taskbar used by Windows 11 24H2 and later.

*/
// ==/WindhawkModReadme==

// ==WindhawkModSettings==
/*
- delayMs: 1
  $name: Thumbnail hover delay
  $description: Exact delay in milliseconds. 1 is effectively immediate.
- closeDelayMs: 1
  $name: Thumbnail close delay
  $description: Exact delay after the pointer leaves the thumbnail area. 1 is effectively immediate.
- closeOnOutsideClick: false
  $name: Close on outside click
  $description: Immediately close open thumbnail previews when clicking outside the taskbar and thumbnail surface.
- openThumbnailsOnGroupedClick: false
  $name: Open thumbnails on grouped click
  $description: Make a normal grouped-button left click open its thumbnail flyout instead of cycling windows. Ctrl+click cycles instead.
*/
// ==/WindhawkModSettings==

#include <windhawk_utils.h>

#include <windows.h>

#include <atomic>

#define MINIMUM_DELAY_MS 1
#define TIME_SPAN_TICKS_PER_MILLISECOND 10000LL

namespace {

std::atomic<LONGLONG> g_hoverDelayTimeSpan{
    MINIMUM_DELAY_MS * TIME_SPAN_TICKS_PER_MILLISECOND};
std::atomic<UINT> g_closeDelayMilliseconds{MINIMUM_DELAY_MS};
std::atomic<bool> g_closeOnOutsideClick{false};
std::atomic<bool> g_openThumbnailsOnGroupedClick{false};
std::atomic<bool> g_taskbarHooksQueued{false};
std::atomic<bool> g_taskbarViewHooksQueued{false};
std::atomic<bool> g_initialized{false};
thread_local UINT g_dismissTransitionDepth = 0;
thread_local void* g_taskbarHost = nullptr;
thread_local bool g_previewLightDismissArmed = false;
thread_local void* g_activeHoverFlyoutController = nullptr;
thread_local bool g_committingLightDismissal = false;
thread_local bool g_pointerOverFlyoutFrame = false;

void* CTaskBand_ITaskListWndSite_Vftable;
void* CSecondaryTaskBand_ITaskListWndSite_Vftable;

using CTaskBandGetTaskbarHost_t =
    void*(WINAPI*)(void* object, void** taskbarHostSharedPointer);
CTaskBandGetTaskbarHost_t CTaskBandGetTaskbarHost_Original;
CTaskBandGetTaskbarHost_t CSecondaryTaskBandGetTaskbarHost_Original;

using ReferenceCountBaseDecrement_t = void(WINAPI*)(void* object);
ReferenceCountBaseDecrement_t ReferenceCountBaseDecrement_Original;

using TaskbarHostRegisterLightDismiss_t = void(WINAPI*)(void* object);
TaskbarHostRegisterLightDismiss_t TaskbarHostRegisterLightDismiss_Original;

using TaskbarHostUnregisterLightDismiss_t = void(WINAPI*)(void* object);
TaskbarHostUnregisterLightDismiss_t TaskbarHostUnregisterLightDismiss_Original;

void WINAPI TaskbarHostUnregisterLightDismiss_Hook(void* object) {
    if (g_taskbarHost == object) {
        g_previewLightDismissArmed = false;
    }

    TaskbarHostUnregisterLightDismiss_Original(object);
}

constexpr int TASK_BAND_INTERFACE_SEARCH_LIMIT = 20;

void* GetTaskbarHostFromWindow(HWND taskbarWindow) {
    WCHAR className[32] = {};
    if (!GetClassNameW(taskbarWindow, className, ARRAYSIZE(className))) {
        return nullptr;
    }

    bool isSecondaryTaskbar =
        _wcsicmp(className, L"Shell_SecondaryTrayWnd") == 0;
    if (!isSecondaryTaskbar &&
        _wcsicmp(className, L"Shell_TrayWnd") != 0) {
        return nullptr;
    }

    void* taskBandInterfaceVftable =
        isSecondaryTaskbar
            ? CSecondaryTaskBand_ITaskListWndSite_Vftable
            : CTaskBand_ITaskListWndSite_Vftable;
    CTaskBandGetTaskbarHost_t getTaskbarHost =
        isSecondaryTaskbar
            ? CSecondaryTaskBandGetTaskbarHost_Original
            : CTaskBandGetTaskbarHost_Original;
    if (!taskBandInterfaceVftable || !getTaskbarHost ||
        !ReferenceCountBaseDecrement_Original) {
        return nullptr;
    }

    HWND taskSwitchWindow =
        isSecondaryTaskbar
            ? FindWindowExW(taskbarWindow, nullptr, L"WorkerW", nullptr)
            : reinterpret_cast<HWND>(
                  GetPropW(taskbarWindow, L"TaskbandHWND"));
    if (!taskSwitchWindow) {
        return nullptr;
    }

    void* taskBand =
        reinterpret_cast<void*>(GetWindowLongPtrW(taskSwitchWindow, 0));
    if (!taskBand) {
        return nullptr;
    }

    void* taskBandForTaskListWindowSite = taskBand;
    int interfaceIndex = 0;
    for (; interfaceIndex < TASK_BAND_INTERFACE_SEARCH_LIMIT;
         interfaceIndex++) {
        void* currentVftable =
            *reinterpret_cast<void**>(taskBandForTaskListWindowSite);
        if (currentVftable == taskBandInterfaceVftable) {
            break;
        }

        taskBandForTaskListWindowSite =
            reinterpret_cast<void**>(taskBandForTaskListWindowSite) + 1;
    }

    if (interfaceIndex == TASK_BAND_INTERFACE_SEARCH_LIMIT) {
        return nullptr;
    }

    void* taskbarHostSharedPointer[2] = {};
    getTaskbarHost(
        taskBandForTaskListWindowSite, taskbarHostSharedPointer);
    void* taskbarHost = taskbarHostSharedPointer[0];
    if (taskbarHostSharedPointer[1]) {
        ReferenceCountBaseDecrement_Original(
            taskbarHostSharedPointer[1]);
    }

    return taskbarHost;
}

void* FindTaskbarHostForCurrentThread() {
    struct FIND_TASKBAR_HOST_CONTEXT {
        void* taskbarHost;
    };

    FIND_TASKBAR_HOST_CONTEXT context = {};
    EnumThreadWindows(
        GetCurrentThreadId(),
        [](HWND window, LPARAM parameter) -> BOOL {
            FIND_TASKBAR_HOST_CONTEXT* context =
                reinterpret_cast<FIND_TASKBAR_HOST_CONTEXT*>(parameter);
            context->taskbarHost = GetTaskbarHostFromWindow(window);
            return context->taskbarHost ? FALSE : TRUE;
        },
        reinterpret_cast<LPARAM>(&context));

    return context.taskbarHost;
}

using SetIsPointerOverFlyoutFrame_t =
    void(WINAPI*)(void* object, bool isPointerOver);
SetIsPointerOverFlyoutFrame_t SetIsPointerOverFlyoutFrame_Original;

void WINAPI SetIsPointerOverFlyoutFrame_Hook(
    void* object,
    bool isPointerOver) {
    g_pointerOverFlyoutFrame = isPointerOver;
    SetIsPointerOverFlyoutFrame_Original(object, isPointerOver);
}

void ArmPreviewLightDismiss() {
    if (g_previewLightDismissArmed ||
        !g_closeOnOutsideClick.load(std::memory_order_relaxed) ||
        !TaskbarHostRegisterLightDismiss_Original ||
        !SetIsPointerOverFlyoutFrame_Original) {
        return;
    }

    if (!g_taskbarHost) {
        g_taskbarHost = FindTaskbarHostForCurrentThread();
    }

    if (!g_taskbarHost) {
        return;
    }

    // LightDismissAction observes the taskbar InputSite without taking focus.
    TaskbarHostRegisterLightDismiss_Original(g_taskbarHost);
    g_previewLightDismissArmed = true;
}

using CommitDismissFlyout_t = void(WINAPI*)(void* object);
CommitDismissFlyout_t CommitDismissFlyout_Original;

void ClearActiveHoverFlyoutController(void* object) {
    if (g_activeHoverFlyoutController == object) {
        g_activeHoverFlyoutController = nullptr;
        g_previewLightDismissArmed = false;
        g_pointerOverFlyoutFrame = false;
    }
}

class LightDismissalScope {
   public:
    LightDismissalScope() noexcept {
        g_committingLightDismissal = true;
    }

    LightDismissalScope(const LightDismissalScope&) = delete;
    LightDismissalScope& operator=(const LightDismissalScope&) = delete;

    ~LightDismissalScope() noexcept {
        g_committingLightDismissal = false;
    }
};

void DismissActiveHoverFlyoutImmediately() {
    if (g_committingLightDismissal ||
        !g_initialized.load(std::memory_order_acquire) ||
        !g_closeOnOutsideClick.load(std::memory_order_relaxed) ||
        !CommitDismissFlyout_Original) {
        return;
    }

    void* hoverFlyoutController = g_activeHoverFlyoutController;
    if (!hoverFlyoutController) {
        return;
    }

    g_activeHoverFlyoutController = nullptr;
    g_previewLightDismissArmed = false;
    g_pointerOverFlyoutFrame = false;
    LightDismissalScope lightDismissalScope;
    CommitDismissFlyout_Original(hoverFlyoutController);
}

void WINAPI CommitDismissFlyout_Hook(void* object) {
    ClearActiveHoverFlyoutController(object);
    CommitDismissFlyout_Original(object);
}

using UpdateFlyoutWindowPosition_t = void(WINAPI*)(void* object);
UpdateFlyoutWindowPosition_t UpdateFlyoutWindowPosition_Original;

void WINAPI UpdateFlyoutWindowPosition_Hook(void* object) {
    UpdateFlyoutWindowPosition_Original(object);

    if (g_initialized.load(std::memory_order_acquire)) {
        g_activeHoverFlyoutController = object;
        ArmPreviewLightDismiss();
    }
}

using HideAllHoverFlyouts_t = void(WINAPI*)(void* object);
HideAllHoverFlyouts_t HideAllHoverFlyouts_Original;

void WINAPI HideAllHoverFlyouts_Hook(void* object) {
    ClearActiveHoverFlyoutController(object);
    HideAllHoverFlyouts_Original(object);
}

using TaskbarControllerOnLightDismissTriggered_t = void(WINAPI*)(
    void* object,
    const void* taskbarModel,
    const void* eventArguments);
TaskbarControllerOnLightDismissTriggered_t
    TaskbarControllerOnLightDismissTriggered_Original;

void WINAPI TaskbarControllerOnLightDismissTriggered_Hook(
    void* object,
    const void* taskbarModel,
    const void* eventArguments) {
    bool pointerOverFlyoutFrame = g_pointerOverFlyoutFrame;
    if (!pointerOverFlyoutFrame) {
        DismissActiveHoverFlyoutImmediately();
    }

    TaskbarControllerOnLightDismissTriggered_Original(
        object, taskbarModel, eventArguments);

    if (pointerOverFlyoutFrame && g_activeHoverFlyoutController) {
        // The taskbar InputSite treats the separate preview island as outside.
        // Preserve the click and rearm after the consumed light-dismiss action.
        ArmPreviewLightDismiss();
    }
}

// This is std::chrono::duration<__int64, std::ratio<1, 10000000>> by value.
using TransitionToFlyoutVisiblePendingState_t =
    void(WINAPI*)(void* object, void* targetItemKey, LONGLONG delayTimeSpan);
TransitionToFlyoutVisiblePendingState_t
    TransitionToFlyoutVisiblePendingState_Original;

void WINAPI TransitionToFlyoutVisiblePendingState_Hook(
    void* object,
    void* targetItemKey,
    LONGLONG delayTimeSpan) {
    LONGLONG configuredDelayTimeSpan =
        g_hoverDelayTimeSpan.load(std::memory_order_relaxed);

    Wh_Log(L"Hover transition: %lld -> %lld TimeSpan ticks",
           delayTimeSpan, configuredDelayTimeSpan);

    TransitionToFlyoutVisiblePendingState_Original(
        object, targetItemKey, configuredDelayTimeSpan);
}

class DismissTransitionScope {
   public:
    DismissTransitionScope() noexcept {
        g_dismissTransitionDepth++;
    }

    DismissTransitionScope(const DismissTransitionScope&) = delete;
    DismissTransitionScope& operator=(const DismissTransitionScope&) = delete;

    ~DismissTransitionScope() noexcept {
        g_dismissTransitionDepth--;
    }
};

using TransitionToFlyoutDismissPendingState_t = void(WINAPI*)(void* object);
TransitionToFlyoutDismissPendingState_t
    TransitionToFlyoutDismissPendingState_Original;

void WINAPI TransitionToFlyoutDismissPendingState_Hook(void* object) {
    DismissTransitionScope dismissTransitionScope;
    TransitionToFlyoutDismissPendingState_Original(object);
}

using MouseHoverTime_t = UINT(WINAPI*)(void* object);
MouseHoverTime_t MouseHoverTime_Original;

UINT WINAPI MouseHoverTime_Hook(void* object) {
    UINT systemDelayMilliseconds = MouseHoverTime_Original(object);
    if (g_dismissTransitionDepth == 0) {
        return systemDelayMilliseconds;
    }

    UINT configuredDelayMilliseconds =
        g_closeDelayMilliseconds.load(std::memory_order_relaxed);

    Wh_Log(L"Close transition: %u -> %u ms",
           systemDelayMilliseconds, configuredDelayMilliseconds);

    return configuredDelayMilliseconds;
}

using ShouldCycleWindows_t = bool(WINAPI*)();
ShouldCycleWindows_t ShouldCycleWindows_Original;

bool WINAPI ShouldCycleWindows_Hook() {
    if (!g_openThumbnailsOnGroupedClick.load(std::memory_order_relaxed)) {
        return ShouldCycleWindows_Original();
    }

    // Preserve Ctrl+click as the inverse action.
    bool controlKeyDown = (GetKeyState(VK_CONTROL) & 0x8000) != 0;
    Wh_Log(L"Grouped click policy: thumbnails=%d control=%d cycle=%d",
           1, controlKeyDown, controlKeyDown);

    return controlKeyDown;
}

void LoadSettings() {
    int delayMilliseconds = Wh_GetIntSetting(L"delayMs");
    if (delayMilliseconds < MINIMUM_DELAY_MS) {
        delayMilliseconds = MINIMUM_DELAY_MS;
    }

    int closeDelayMilliseconds = Wh_GetIntSetting(L"closeDelayMs");
    if (closeDelayMilliseconds < MINIMUM_DELAY_MS) {
        closeDelayMilliseconds = MINIMUM_DELAY_MS;
    }

    LONGLONG delayTimeSpan =
        static_cast<LONGLONG>(delayMilliseconds) *
        TIME_SPAN_TICKS_PER_MILLISECOND;
    g_hoverDelayTimeSpan.store(delayTimeSpan, std::memory_order_relaxed);
    g_closeDelayMilliseconds.store(
        static_cast<UINT>(closeDelayMilliseconds),
        std::memory_order_relaxed);
    g_closeOnOutsideClick.store(
        Wh_GetIntSetting(L"closeOnOutsideClick") != 0,
        std::memory_order_relaxed);
    g_openThumbnailsOnGroupedClick.store(
        Wh_GetIntSetting(L"openThumbnailsOnGroupedClick") != 0,
        std::memory_order_relaxed);

    Wh_Log(L"Settings: delayMs=%d closeDelayMs=%d "
           L"closeOnOutsideClick=%d openThumbnailsOnGroupedClick=%d",
           delayMilliseconds,
           closeDelayMilliseconds,
           g_closeOnOutsideClick.load(std::memory_order_relaxed),
           g_openThumbnailsOnGroupedClick.load(std::memory_order_relaxed));
}

HMODULE GetTaskbarModuleHandle() {
    return GetModuleHandleW(L"Taskbar.dll");
}

HMODULE GetTaskbarViewModuleHandle() {
    HMODULE module = GetModuleHandleW(L"Taskbar.View.dll");
    if (!module) {
        module = GetModuleHandleW(L"ExplorerExtensions.dll");
    }

    return module;
}

bool HookTaskbarSymbols(HMODULE module) {
    if (!module) {
        return false;
    }

    bool expected = false;
    if (!g_taskbarHooksQueued.compare_exchange_strong(
            expected, true, std::memory_order_relaxed)) {
        return true;
    }

    WindhawkUtils::SYMBOL_HOOK taskbarDllHooks[] = {
        {
            {
                LR"(const CTaskBand::`vftable'{for `ITaskListWndSite'})",
            },
            &CTaskBand_ITaskListWndSite_Vftable,
            nullptr,
            true,
        },
        {
            {
                LR"(const CSecondaryTaskBand::`vftable'{for `ITaskListWndSite'})",
            },
            &CSecondaryTaskBand_ITaskListWndSite_Vftable,
            nullptr,
            true,
        },
        {
            {
                LR"(public: virtual class std::shared_ptr<class TaskbarHost> __cdecl CTaskBand::GetTaskbarHost(void)const )",
            },
            &CTaskBandGetTaskbarHost_Original,
            nullptr,
            true,
        },
        {
            {
                LR"(public: virtual class std::shared_ptr<class TaskbarHost> __cdecl CSecondaryTaskBand::GetTaskbarHost(void)const )",
            },
            &CSecondaryTaskBandGetTaskbarHost_Original,
            nullptr,
            true,
        },
        {
            {
                LR"(public: void __cdecl std::_Ref_count_base::_Decref(void))",
            },
            &ReferenceCountBaseDecrement_Original,
            nullptr,
            true,
        },
        {
            {
                LR"(private: void __cdecl TaskbarHost::RegisterLightDismiss(void))",
            },
            &TaskbarHostRegisterLightDismiss_Original,
            nullptr,
            true,
        },
        {
            {
                LR"(private: void __cdecl TaskbarHost::UnregisterLightDismiss(void))",
            },
            &TaskbarHostUnregisterLightDismiss_Original,
            TaskbarHostUnregisterLightDismiss_Hook,
            true,
        },
    };

    if (!WindhawkUtils::HookSymbols(module, taskbarDllHooks,
                                    ARRAYSIZE(taskbarDllHooks))) {
        Wh_Log(L"Failed to resolve Taskbar.dll symbols");
        g_taskbarHooksQueued.store(false, std::memory_order_relaxed);
        return false;
    }

    if (!TaskbarHostRegisterLightDismiss_Original ||
        !CTaskBand_ITaskListWndSite_Vftable ||
        !CTaskBandGetTaskbarHost_Original ||
        !ReferenceCountBaseDecrement_Original) {
        Wh_Log(L"Taskbar light-dismiss support isn't available on this build");
    }

    return true;
}

bool HookTaskbarViewSymbols(HMODULE module) {
    if (!module) {
        return false;
    }

    bool expected = false;
    if (!g_taskbarViewHooksQueued.compare_exchange_strong(
            expected, true, std::memory_order_relaxed)) {
        return true;
    }

    // Taskbar.View.dll, ExplorerExtensions.dll
    WindhawkUtils::SYMBOL_HOOK taskbarViewHooks[] = {
        {
            {
                LR"(private: void __cdecl winrt::Taskbar::implementation::HoverFlyoutModel::TransitionToFlyoutVisiblePendingState(struct winrt::hstring,class std::chrono::duration<__int64,struct std::ratio<1,10000000> >))",
                LR"(private: void __cdecl winrt::Taskbar::implementation::HoverFlyoutModel::TransitionToFlyoutVisiblePendingState(struct winrt::hstring,class std::chrono::duration<long long,struct std::ratio<1,10000000> >))",
            },
            &TransitionToFlyoutVisiblePendingState_Original,
            TransitionToFlyoutVisiblePendingState_Hook,
        },
        {
            {
                LR"(private: void __cdecl winrt::Taskbar::implementation::HoverFlyoutController::CommitDismissFlyout(void))",
            },
            &CommitDismissFlyout_Original,
            CommitDismissFlyout_Hook,
            true,
        },
        {
            {
                LR"(private: void __cdecl winrt::Taskbar::implementation::HoverFlyoutController::UpdateFlyoutWindowPosition(void))",
            },
            &UpdateFlyoutWindowPosition_Original,
            UpdateFlyoutWindowPosition_Hook,
            true,
        },
        {
            {
                LR"(public: void __cdecl winrt::Taskbar::implementation::HoverFlyoutModel::SetIsPointerOverFlyoutFrame(bool))",
            },
            &SetIsPointerOverFlyoutFrame_Original,
            SetIsPointerOverFlyoutFrame_Hook,
            true,
        },
        {
            {
                LR"(private: void __cdecl winrt::Taskbar::implementation::HoverFlyoutController::HideAllHoverFlyouts(void))",
            },
            &HideAllHoverFlyouts_Original,
            HideAllHoverFlyouts_Hook,
            true,
        },
        {
            {
                LR"(private: void __cdecl winrt::Taskbar::implementation::TaskbarController::OnLightDismissTriggered(struct winrt::WindowsUdk::UI::Shell::TaskbarModel const &,struct winrt::Windows::Foundation::IInspectable const &))",
            },
            &TaskbarControllerOnLightDismissTriggered_Original,
            TaskbarControllerOnLightDismissTriggered_Hook,
            true,
        },
        {
            {
                LR"(private: void __cdecl winrt::Taskbar::implementation::HoverFlyoutModel::TransitionToFlyoutDismissPendingState(void))",
            },
            &TransitionToFlyoutDismissPendingState_Original,
            TransitionToFlyoutDismissPendingState_Hook,
            true,
        },
        {
            {
                LR"(public: __cdecl winrt::impl::consume_Windows_UI_ViewManagement_IUISettings<struct winrt::Windows::UI::ViewManagement::IUISettings>::MouseHoverTime(void)const )",
                LR"(public: unsigned int __cdecl winrt::impl::consume_Windows_UI_ViewManagement_IUISettings<struct winrt::Windows::UI::ViewManagement::IUISettings>::MouseHoverTime(void)const )",
            },
            &MouseHoverTime_Original,
            MouseHoverTime_Hook,
            true,
        },
        {
            {
                LR"(bool __cdecl ShouldCycleWindows(void))",
            },
            &ShouldCycleWindows_Original,
            ShouldCycleWindows_Hook,
            true,
        },
    };

    if (!WindhawkUtils::HookSymbols(module, taskbarViewHooks,
                                    ARRAYSIZE(taskbarViewHooks))) {
        Wh_Log(L"Failed to resolve Taskbar.View symbols");
        g_taskbarViewHooksQueued.store(false, std::memory_order_relaxed);
        return false;
    }

    if (!ShouldCycleWindows_Original) {
        Wh_Log(L"ShouldCycleWindows isn't available; grouped-click override "
               L"is disabled on this build");
    }

    if (!TransitionToFlyoutDismissPendingState_Original ||
        !MouseHoverTime_Original) {
        Wh_Log(L"Thumbnail close-delay symbols aren't available; instant "
               L"close is disabled on this build");
    }

    if (!TaskbarControllerOnLightDismissTriggered_Original ||
        !UpdateFlyoutWindowPosition_Original ||
        !SetIsPointerOverFlyoutFrame_Original ||
        !CommitDismissFlyout_Original) {
        Wh_Log(L"Thumbnail light-dismiss symbols aren't available; "
               L"close-on-outside-click is disabled on this build");
    }

    WCHAR modulePath[MAX_PATH] = {};
    if (!GetModuleFileNameW(module, modulePath, ARRAYSIZE(modulePath))) {
        wcscpy_s(modulePath, L"(unknown module)");
    }

    Wh_Log(L"Taskbar.View hooks queued for %s", modulePath);
    return true;
}

void HandleLoadedModule(HMODULE module) {
    if (!module) {
        return;
    }

    bool hooksQueued = false;
    if (GetTaskbarModuleHandle() == module &&
        !g_taskbarHooksQueued.load(std::memory_order_relaxed)) {
        hooksQueued = HookTaskbarSymbols(module);
    }

    if (GetTaskbarViewModuleHandle() == module &&
        !g_taskbarViewHooksQueued.load(std::memory_order_relaxed)) {
        hooksQueued = HookTaskbarViewSymbols(module) || hooksQueued;
    }

    if (hooksQueued &&
        g_initialized.load(std::memory_order_relaxed) &&
        !Wh_ApplyHookOperations()) {
        Wh_Log(L"Failed to apply late taskbar hooks");
    }
}

using LoadLibraryExW_t = decltype(&LoadLibraryExW);
LoadLibraryExW_t LoadLibraryExW_Original;

HMODULE WINAPI LoadLibraryExW_Hook(LPCWSTR fileName,
    HANDLE file,
    DWORD flags) {
    HMODULE module = LoadLibraryExW_Original(fileName, file, flags);
    HandleLoadedModule(module);
    return module;
}

bool HookLoadLibraryExW() {
    HMODULE kernelBase = GetModuleHandleW(L"kernelbase.dll");
    if (!kernelBase) {
        Wh_Log(L"kernelbase.dll isn't loaded");
        return false;
    }

    void* loadLibraryExW =
        reinterpret_cast<void*>(GetProcAddress(kernelBase, "LoadLibraryExW"));
    if (!loadLibraryExW) {
        Wh_Log(L"LoadLibraryExW wasn't found");
        return false;
    }

    if (!Wh_SetFunctionHook(
            loadLibraryExW,
            reinterpret_cast<void*>(LoadLibraryExW_Hook),
            reinterpret_cast<void**>(&LoadLibraryExW_Original))) {
        Wh_Log(L"Failed to hook LoadLibraryExW");
        return false;
    }

    return true;
}

}  // namespace

BOOL Wh_ModInit() {
    Wh_Log(L"Initializing");
    LoadSettings();

    if (!HookLoadLibraryExW()) {
        return FALSE;
    }

    HMODULE taskbarModule = GetTaskbarModuleHandle();
    if (taskbarModule && !HookTaskbarSymbols(taskbarModule)) {
        Wh_Log(L"Taskbar.dll light-dismiss hooks weren't installed");
    }

    HMODULE taskbarViewModule = GetTaskbarViewModuleHandle();
    if (taskbarViewModule && !HookTaskbarViewSymbols(taskbarViewModule)) {
        return FALSE;
    }

    g_initialized.store(true, std::memory_order_relaxed);
    Wh_Log(L"Initialized");
    return TRUE;
}

void Wh_ModAfterInit() {
    bool hooksQueued = false;

    if (!g_taskbarHooksQueued.load(std::memory_order_relaxed)) {
        HMODULE taskbarModule = GetTaskbarModuleHandle();
        if (taskbarModule) {
            hooksQueued = HookTaskbarSymbols(taskbarModule);
        }
    }

    if (!g_taskbarViewHooksQueued.load(std::memory_order_relaxed)) {
        HMODULE taskbarViewModule = GetTaskbarViewModuleHandle();
        if (taskbarViewModule) {
            hooksQueued =
                HookTaskbarViewSymbols(taskbarViewModule) || hooksQueued;
        } else {
            Wh_Log(L"Taskbar.View isn't loaded yet");
        }
    }

    if (hooksQueued && !Wh_ApplyHookOperations()) {
        Wh_Log(L"Failed to apply taskbar hooks in Wh_ModAfterInit");
    }
}

void Wh_ModSettingsChanged() {
    LoadSettings();
}

void Wh_ModUninit() {
    g_initialized.store(false, std::memory_order_relaxed);
    g_closeOnOutsideClick.store(false, std::memory_order_relaxed);
    g_previewLightDismissArmed = false;
    g_activeHoverFlyoutController = nullptr;
    g_pointerOverFlyoutFrame = false;
    g_taskbarHost = nullptr;

    Wh_Log(L"Uninitialized");
}
